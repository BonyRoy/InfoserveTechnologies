import React from "react";
import s1 from "../src/images/s1.jpg";
import s2 from "../src/images/s2.jpg";
import s3 from "../src/images/s3.jpg";

const Services =()=>{
    return(
        <>
        <div className="container-fluid" 
                    style={{
                        backgroundColor: '#a7bfe0',
                        }}
        >
            <h1 className="tab-center"
                        style={{
                            color: '#c79903',
                            fontFamily:'cursive',
                            fontWeight: '150',
                            fontSize: '40px',
                            backgroundColor: '#def188',
                            }}
            >Our Services:-</h1>
            <div className="row">
             <div className="col-10 mx-auto">
                 <div className="row">
                     <div className="col-md-4 col-10 mx-auto">
                     <div className="ml-auto">
<div className="card" style={{width:'0rem'}}></div>
<img src={s1} class="card-img-top" alt="..."/>
<div class="card-body">
<p class="card-text"
            style={{
                backgroundColor: '#def188',
                }}
>We have received significant attention recently as it is based on a simple yet powerful Service-Oriented Architecture (SOA) that supports easy software interoperability via standard Web service protocols. Many production and research projects have been initiated and carried out, aiming at finding a new way of developing and using software, by major computer and software corporations.</p>
<p class="card-text"
            style={{
              color: '#0a2852',
              fontFamily:'monospace',
              fontWeight: '150',
              backgroundColor: '#88f1e8',
              }}
>We Provides:
Custom Development ||	Integration || Software Support ||	Staffing
</p>
</div>
<img src={s2} class="card-img-top" alt="..."/>
<div class="card-body">
<p class="card-text"
            style={{
                backgroundColor: '#def188',
                }}
>Database as a services we a focused to realm within the greater field known as SaaS — it’s the delivery of database software and related physical database storage as a service. For something to be categorized as “Database as a Service,”</p>
<p class="card-text"
            style={{
                color: '#0a2852',
                fontFamily:'monospace',
                fontWeight: '150',
                backgroundColor: '#88f1e8',
                }}
>We Provides:
Custom Development (CR)	|| Functional and Technical Support ||	Business Process Consolidation (BPC) || 
Database Support ( BASIS) ||	Business Intelligence (BI)	Staffing
</p>
</div>
<img src={s3} class="card-img-top" alt="..."/>
<div class="card-body">
<p class="card-text"
            style={{
                backgroundColor: '#def188',
                }}
>Files Operating As demands on the IT infrastructure is rapidly increasing, several companies are looking for a reliable and cost effective means for maintaining their IT applications and systems and optimizing their internal infrastructure management processes.</p>
<p class="card-text"
            style={{
                color: '#0a2852',
                fontFamily:'monospace',
                fontWeight: '150',
                backgroundColor: '#88f1e8',
                }}
>We Provides:
Hosting of Customer application || Hardware supply
</p>
</div>
</div>
                     </div>
                 </div>
             </div>
            </div>
        </div>

        </>
        );
};

export default Services;