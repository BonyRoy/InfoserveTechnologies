import React from "react";
import c1 from "../src/images/c1.jpg";
import c2 from "../src/images/c2.jpg";
import c3 from "../src/images/c3.jpg";
import c4 from "../src/images/c4.jpg";

const About =()=>{
    return(
        <>
        <section id="header" className="d-flex align-items-center">
        <div className="container-fluid nav_bg"
               style={ {
                backgroundColor: '#9ae7ff',
            }}
        >
<div class="card-body">
<p class="card-text" 
style={{
    color: '#ff7300',
    fontFamily:'cursive',
    }}
>20 Plus Years of Technical experience. Core and in depth knowledge of business like Manufacturing, Insurance, Hospitality and Municipal Corporation. Man Management with proven track record for employee retention. Sales engagement and strong network for month by month sales growth. Strong in response and delivery to customer. This is our key to success.</p>
<a href="#" class="btn btn-outline-dark">Join Us Now</a>
<br></br>
<br></br>

<div class="card-body">
<h5 class="card-title"
style={{
    color: '#17f003',
    fontFamily:'cursive',
    backgroundColor: '#f8ff9a',
    }}
>Our Clients</h5>

<div className='col-md-4 col-10 mx-auto '>
<div className="card" style={{width:'0rem'}}></div>
<img src={c1} class="card-img-top" alt="..."/>
<img src={c2} class="card-img-top" alt="..."/>
<img src={c3} class="card-img-top" alt="..."/>
<img src={c4} class="card-img-top" alt="..."/>

</div>
</div>
        </div>
        </div>

        </section>
        </>
        );
};

export default About;