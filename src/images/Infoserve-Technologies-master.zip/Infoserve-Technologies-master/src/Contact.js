import React from "react";



const Contact =()=>{
    return(
        <>
        <section id="header" className="d-flex align-items-center">
        <div className="container-fluid nav_bg"
               style={ {
                backgroundColor: '#a7bfe0',
            }}
        >
        <div className="row">
        <div className="col-10 mx-auto">
            <div className="row">
        <div className="col-md-10 pt-5 pt-lg-0 order-2 order-lg-1 d-flex justify-content-center flex-column">
<div class="card-body">
<h5 class="card-title"
            style={{
                backgroundColor: '#ffbc9d',
                }}
>Get In Touch</h5>
<br></br>
<p
            style={{
                backgroundColor: '#e0ffec',
                }}
>NP InfoServe Technologies Pvt.Ltd. We are located in thane (west) Below is all the details about our company</p>
<p class="card-text"
            style={{
                backgroundColor: '#e2ff9d',
                }}
>Contact Number:- + 91 77188 25757</p>
<p class="card-text"
            style={{
                backgroundColor: '#ee9d9d',
                }}
>Email:- info@npinfoserve.com
</p>
</div>
        </div>
            </div>
        </div>
        </div>
        </div>
        </section>
        </>
        );
};

export default Contact;