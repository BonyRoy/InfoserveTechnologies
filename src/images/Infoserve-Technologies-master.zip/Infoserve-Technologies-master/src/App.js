import React from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'; 
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import Home from "./Home";
import Service from "./Service";
import Contact from "./Contact";
import About from "./About";
import Navbar from "./Navbar";
import { Routes ,Route } from 'react-router-dom';


const App =()=>{
    return(
        <>
        <div className="col-md-4 col-10 mx-auto"
                  style={{
                    color: '#a6acff',
                    backgroundColor: '#252a72',
                    }}
        >
            <p>for query just call us at ...+ 91 77188 25757</p>
        </div>
        <Navbar />
        <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/Service" element={<Service/>}/>
            <Route path="/contact" element={<Contact/>}/>
            <Route path="/about" element={<About/>}/>
        </Routes>
        </>
        );
};

export default App;